from .settings import *


DEBUG = True